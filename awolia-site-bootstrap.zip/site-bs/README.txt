Awolia Muslim Schools - website project (Bootstrap utilities version)
Open index.html with VS Code + the "Live Server" extension.

index.html              -> page structure (Bootstrap classes: d-flex, align-items-center, justify-content-between, position-relative, text-center)
css/bootstrap-subset.css -> Bootstrap v5.3.2 (MIT): only the 5 utility classes used. NO Reboot, so the look is untouched.
css/style.css           -> all other styling (colors are CSS variables at the top: :root)
js/script.js            -> menu, buttons, and the fit-to-screen scaling
images/                 -> logo, backgrounds, icons, avatars (replace files, keep the same names)

To use another Bootstrap utility, copy its rule from the official Bootstrap docs into css/bootstrap-subset.css.
Do not load the full bootstrap.css: it changes fonts, links and spacing, and our .btn and .card class names would clash with Bootstrap's.

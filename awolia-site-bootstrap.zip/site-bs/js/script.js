function act(s){document.querySelectorAll(s+' a').forEach(function(a){a.addEventListener('click',function(e){e.preventDefault();document.querySelectorAll(s+' a').forEach(function(x){x.classList.remove('on')});a.classList.add('on')})})}
act('#nav');act('#bnav');
var b=document.getElementById('burger');b.addEventListener('click',function(){var o=document.getElementById('nav').classList.toggle('open');b.setAttribute('aria-expanded',o)});
document.getElementById('chBtn').addEventListener('click',function(){this.textContent='Good luck! 🍀'});
function bgh(){var s=document.querySelector('.scene');s.style.setProperty('--bgh',(s.clientWidth/2.5)+'px')}
function fit(){var s=document.querySelector('.scene'),w=s.querySelector('.wrap'),cs=getComputedStyle(s),W=s.clientWidth-parseFloat(cs.paddingLeft)-parseFloat(cs.paddingRight),av=s.clientHeight-parseFloat(cs.paddingTop)-parseFloat(cs.paddingBottom),z=1;if(innerWidth>1100){w.style.width='1000px';w.style.zoom=1;w.style.zoom=Math.max(.3,Math.min(W/1000,av/w.offsetHeight));return}if(innerWidth<=820)W=Math.min(W,560);for(var i=0;i<6;i++){w.style.zoom=1;w.style.width=(W/z)+'px';var nz=Math.max(.5,Math.min(1,av/w.offsetHeight));if(Math.abs(nz-z)<.005){z=nz;break}z=nz}w.style.width=(W/z)+'px';w.style.zoom=z}
addEventListener('resize',function(){bgh();fit()});addEventListener('load',function(){bgh();fit()});bgh();fit();
(function(){if(matchMedia('(prefers-reduced-motion:reduce)').matches)return;var s=document.querySelector('.scene'),tx=0,ty=0,cx=0,cy=0,run=false;
function loop(){cx+=(tx-cx)*.06;cy+=(ty-cy)*.06;s.style.setProperty('--mx',cx.toFixed(3));s.style.setProperty('--my',cy.toFixed(3));if(Math.abs(tx-cx)>.002||Math.abs(ty-cy)>.002)requestAnimationFrame(loop);else run=false}
function kick(){if(!run){run=true;requestAnimationFrame(loop)}}
addEventListener('pointermove',function(e){tx=(e.clientX/innerWidth-.5)*2;ty=e.clientY/innerHeight;kick()},{passive:true});
function gyro(e){if(e.gamma==null)return;tx=Math.max(-1,Math.min(1,e.gamma/25));ty=Math.max(0,Math.min(1,((e.beta||0)-30)/50));kick()}
addEventListener('deviceorientation',gyro);
addEventListener('pointerdown',function once(){removeEventListener('pointerdown',once);if(window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission){DeviceOrientationEvent.requestPermission().then(function(r){if(r==='granted')addEventListener('deviceorientation',gyro)}).catch(function(){})}});
})();
